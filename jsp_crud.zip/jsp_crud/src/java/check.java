/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 *
 * @author popat
 */
public class check implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String nm = request.getParameter("nm");
        String age = request.getParameter("age");
        String std = request.getParameter("std");
        
        if (nm.equals("")) {
            out.println("enter name please");
        }else if(age.equals("")){
            out.println("enter age please");
        }else if(std.equals("")){
            out.println("enter std please");
        }else
        {
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {

    }
}
